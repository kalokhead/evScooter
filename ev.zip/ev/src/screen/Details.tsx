import {
  Dimensions,
  Image,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import React from "react";
import FontAwesome from "@expo/vector-icons/FontAwesome";
import Feather from "@expo/vector-icons/Feather";

const LeftSide = require("../../images/2.png");
const { width, height } = Dimensions.get("window");

const Details = (props) => {
  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => props.navigation.goBack()}>
          <Feather name="chevron-left" color="#FFF" size={25} />
        </TouchableOpacity>
        <Feather name="shopping-cart" color="#FFF" size={25} />
      </View>
      {/* Image */}
      <View style={styles.imageContainer}>
        <Image source={LeftSide} style={styles.image} />
      </View>
      {/* Description */}
      <View style={styles.descriptionContainer}>
        <Text style={styles.title}>Maxx Scooter</Text>
        <Text style={styles.subtitle}>Model S1</Text>
        <View style={styles.colorContainer}>
          <Text style={styles.title}>Colors</Text>
          <View style={styles.colorOptions}>
            <View style={styles.selected}>
              <View style={styles.color1} />
            </View>
            <View style={styles.color2} />
            <View style={styles.color3} />
          </View>
        </View>
        <Text style={styles.description}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </Text>
        <View style={styles.actionContainer}>
          <FontAwesome name="heart-o" color="#000" size={25} />
          <TouchableOpacity
            onPress={() => props.navigation.navigate("Home")}
            style={styles.nextButton}
          >
            <Text style={styles.nextButtonText}>Next</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default Details;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignContent: "center",
    backgroundColor: "#121212",
  },
  header: {
    flex: 0.05,
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 8,
    alignItems: "center",
  },
  imageContainer: {
    flex: 0.4,
    justifyContent: "center",
    alignItems: "center",
  },
  image: {
    width: width,
    height: height / 2,
    resizeMode: "contain",
  },
  descriptionContainer: {
    flex: 0.55,
    borderRadius: 50,
    backgroundColor: "#FFF",
    padding: 8,
  },
  title: {
    fontSize: 25,
    fontFamily: "Montserrat_700Bold",
    marginTop: 30,
  },
  subtitle: {
    fontSize: 20,
    color: "#474747",
    marginTop: 10,
    fontFamily: "Montserrat_400Regular",
  },
  colorContainer: {
    justifyContent: "space-between",
    flexDirection: "row",
  },
  colorOptions: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 30,
  },
  description: {
    fontFamily: "Montserrat_400Regular",
    fontSize: 18,
    paddingRight: 80,
    lineHeight: 25,
    paddingTop: 12,
  },
  actionContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 20,
    padding: 8,
  },
  nextButton: {
    paddingHorizontal: 50,
    backgroundColor: "#E2443B",
    paddingVertical: 10,
    borderRadius: 15,
  },
  nextButtonText: {
    fontFamily: "Montserrat_600SemiBold",
    fontSize: 20,
    color: "#FFF",
  },
  color1: {
    height: 20,
    width: 20,
    borderRadius: 15,
    backgroundColor: "#E2443B",
  },
  color2: {
    height: 20,
    width: 20,
    borderRadius: 15,
    backgroundColor: "#529C47",
    marginHorizontal: 10,
  },
  color3: {
    height: 20,
    width: 20,
    borderRadius: 15,
    backgroundColor: "#529CC0",
  },
  selected: {
    borderColor: "#E2443B",
    height: 30,
    width: 30,
    borderRadius: 24,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
});
