import {
  Dimensions,
  Image,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import React from "react";

const frontEV = require("../../images/1.png");
const { width, height } = Dimensions.get("window");

const Home = (props) => {
  return (
    <SafeAreaView style={styles.container}>
      {/* Image and description view */}
      <View style={styles.imageDescriptionContainer}>
        <Image source={frontEV} style={styles.image} />
        <Text style={styles.title}>Maxx Scooter</Text>
        <Text style={styles.description}>
          With an updated motor, and integrated anti-theft tech the Maxx
          scooters are custom-tuned for the ultimate riding experience.
        </Text>
      </View>
      {/* Button View */}
      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={styles.nextButton}
          onPress={() => {
            props.navigation.navigate("Details");
          }}
        >
          <Text style={styles.nextButtonText}>Next</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default Home;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#121212",
    justifyContent: "center",
    alignItems: "center",
  },
  imageDescriptionContainer: {
    flex: 0.8,
    justifyContent: "center",
    alignItems: "center",
  },
  image: {
    width: width,
    height: height / 2,
    resizeMode: "contain",
  },
  title: {
    color: "#FFF",
    fontFamily: "Montserrat_700Bold",
    fontSize: 30,
    marginTop: 20,
  },
  description: {
    color: "#FFF",
    fontFamily: "Montserrat_400Regular",
    fontSize: 18,
    textAlign: "center",
    paddingHorizontal: 20,
    lineHeight: 30,
    marginTop: 30,
  },
  buttonContainer: {
    flex: 0.2,
    alignItems: "center",
    justifyContent: "flex-end",
    paddingBottom: 20,
  },
  nextButton: {
    backgroundColor: "#E2443B",
    paddingHorizontal: 120,
    paddingVertical: 10,
    borderRadius: 30,
  },
  nextButtonText: {
    fontFamily: "Montserrat_600SemiBold",
    fontSize: 30,
    color: "#FFF",
  },
});
